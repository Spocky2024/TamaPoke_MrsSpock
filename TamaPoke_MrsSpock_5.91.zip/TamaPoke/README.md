TAMAPOKE – FLASHING GUIDE (Arduino IDE)                       Firmware v5.91
==============================================================================

This guide explains how to put TamaPoke onto the "Waveshare
ESP32-S3-Touch-AMOLED-1.75" using the Arduino IDE, which boards and
libraries are required, and how to prepare the SD card.


1. REQUIREMENTS
------------------------------------------------------------------------------
 - Arduino IDE 2.x (Windows, macOS or Linux)
 - A USB-C cable that carries data (not a charge-only cable)
 - A microSD card (see section 6)
 - The complete TamaPoke folder. It must be named "TamaPoke" (exactly like
   the main file TamaPoke.ino) and contain these files:

     TamaPoke.ino
     audio.cpp   audio.h
     dex.h
     i18n.cpp    i18n.h
     imu.cpp     imu.h
     pet.cpp     pet.h
     pin_config.h
     rtcbat.cpp  rtcbat.h
     sdmon.cpp   sdmon.h
     species.h

   When you open TamaPoke.ino, the IDE loads all of these files with it.


2. INSTALL THE BOARD PACKAGE (ESP32)
------------------------------------------------------------------------------
 1. Arduino IDE > Preferences (macOS: Arduino IDE > Settings).
 2. Under "Additional boards manager URLs" add:

      https://espressif.github.io/arduino-esp32/package_esp32_index.json

 3. Tools > Board > Boards Manager > search for "esp32".
 4. Install "esp32 by Espressif Systems".
    The project was built with version 3.3.11 (according to the build data).
    Use this version if you want identical results; newer 3.x versions
    should work as well but have not been tested.

The ESP32 package already includes the following (install nothing extra):
Wire, Preferences, FS, SD_MMC, ESP_I2S, BLE (BLEDevice, BLEServer,
BLEClient, BLEScan, BLEUtils) and FreeRTOS.


3. INSTALL THE LIBRARIES (three of them)
------------------------------------------------------------------------------
Sketch > Include Library > Manage Libraries, then search for and install:

  Library                    Author                Used for
  -------------------------  --------------------  --------------------------
  GFX Library for Arduino    moononournation       Display (CO5300, QSPI)
  SensorLib                  Lewis He (lewisxhe)   Touch CST9217, clock
                                                   PCF85063, motion sensor
                                                   QMI8658
  XPowersLib                 Lewis He (lewisxhe)   Power chip AXP2101

 - Install the current version of each from the Library Manager.
 - The version numbers of the libraries could not be read from the project
   files. If you want to record your versions, you will find them in the
   file library.properties inside each library's folder (macOS/Linux:
   ~/Documents/Arduino/libraries/<library>/).
 - The program includes: Arduino_GFX_Library.h, TouchDrvCSTXXX.hpp,
   SensorQMI8658.hpp, SensorPCF85063.hpp, XPowersLib.h.


4. BOARD SETTINGS ("Tools" menu)
------------------------------------------------------------------------------
Board:  "ESP32S3 Dev Module"   (identifier: esp32:esp32:esp32s3)

  Setting                              Value
  -----------------------------------  ----------------------------------------
  USB CDC On Boot                      Enabled
  CPU Frequency                        240MHz (WiFi)
  Core Debug Level                     None
  USB DFU On Boot                      Disabled
  Erase All Flash Before Sketch Upload Disabled
  Events Run On                        Core 1
  Flash Mode                           QIO 80MHz
  Flash Size                           16MB (128Mb)
  JTAG Adapter                         Disabled
  Arduino Runs On                      Core 1
  USB Firmware MSC On Boot             Disabled
  Partition Scheme                     16M Flash (3MB APP/9.9MB FATFS)
                                       (internal name: app3M_fat9M_16MB)
  PSRAM                                OPI PSRAM
  Upload Mode                          UART0 / Hardware CDC
  Upload Speed                         921600
  USB Mode                             Hardware CDC and JTAG
  Zigbee Mode                          Disabled

IMPORTANT:
 - PSRAM must be set to "OPI PSRAM". The display's frame buffer
   (466 x 466 pixels) lives in PSRAM; with any other setting the device does
   not start properly.
 - Flash Size 16MB and the Partition Scheme must match. If the scheme is not
   offered in the list, your ESP32 package is too old.

For command-line users (arduino-cli), this corresponds to the identifier:

  esp32:esp32:esp32s3:UploadSpeed=921600,USBMode=hwcdc,CDCOnBoot=cdc,
  MSCOnBoot=default,DFUOnBoot=default,UploadMode=default,CPUFreq=240,
  FlashMode=qio,FlashSize=16M,PartitionScheme=app3M_fat9M_16MB,
  DebugLevel=none,PSRAM=opi,LoopCore=1,EventsCore=1,EraseFlash=none,
  JTAGAdapter=default,ZigbeeMode=default
  (all on one line, without spaces)

The names of the menu items can differ slightly depending on the version of
the IDE and the ESP32 package; the identifier above is what counts.


5. UPLOADING (FLASHING)
------------------------------------------------------------------------------
 1. Connect the device to the computer with USB-C.
 2. Tools > Port: select the device's port
    (macOS: /dev/cu.usbmodem..., Windows: COMx).
 3. Close the Serial Monitor (a port can only be used by one program).
 4. Click "Upload" (the arrow). Compiling and uploading take a few minutes.
 5. After "Hard resetting via RTS pin..." the device restarts.

If the port does not appear or the upload fails, put the device into download
mode (common for ESP32-S3 boards in general): hold the BOOT button, plug in
the USB cable, release BOOT, then upload again.

On first start, the Serial Monitor (115200 baud) shows, among other things:

  TamaPoke fw v5.91
  SD montada: ... MB
  miniaturas cargadas: 386 (...)
  QMI8658 ok id=0x7C

(These log lines are in Spanish in the firmware; that is normal.)

If "miniaturas cargadas: 386" is missing, the files on the SD card are not set
up correctly (see section 6).


6. PREPARING THE SD CARD
------------------------------------------------------------------------------
The Pokémon images are stored on the microSD card.

  >>> Copy the CONTENTS of the supplied folder "SD Karte" into the ROOT
  >>> DIRECTORY of the SD card – the contents, not the folder itself.

Correct:    The folder "mons" is located directly in the root directory of the
            card (containing files such as p001.bin, ps001.bin and
            thumbs.bin).
Wrong:      The card contains a folder "SD Karte" and only inside it the
            folder "mons". The device will not find the images this way.

Notes:
 - Insert the card while the device is switched off.
 - WARNING: If the device cannot mount the card (for example because of an
   unknown file system), IT FORMATS THE CARD ITSELF. All data on the card is
   lost in that case. Do not use a card with important data on it.
 - Without the images the device shows "No sprites / Load them onto the SD".
 - Erasing the device (section 7) does not touch the SD card.


7. ERASING THE DEVICE BEFORE FLASHING (if a program is already on it)
------------------------------------------------------------------------------
Normally this is NOT necessary: an upload replaces the program and the
partition table. The saved game lives in a separate area (NVS) and is kept.

Erasing makes sense if
 - a different program was on the device before,
 - you want to start with a completely empty device and a new saved game,
 - or the device fails to start after uploading in an unusual way.

How to do it in the Arduino IDE:
 1. Tools > set "Erase All Flash Before Sketch Upload" to "Enabled".
 2. Upload as usual. The entire flash memory (program AND saved game) is
    erased and rewritten. The SD card is not touched.
 3. AFTERWARDS set the option back to "Disabled". Otherwise the saved game
    is erased on every further upload.

To erase only the saved game (without flashing again):
 - In the game: swipe down > hold the upper half for 2 seconds > hold
   "Hold to delete" for 2 seconds > tap the six numbers in the circle in
   order within 10 seconds.
 - Or send the command  WIPE  in the Serial Monitor.


8. FIRST START IN THE GAME
------------------------------------------------------------------------------
 1. Choose your starter (Bulbasaur, Charmander or Squirtle), then tap the egg
    15 times.
 2. Set the clock: swipe down, hold the upper half for 2 seconds, set hours
    and minutes, "OK". The game follows local time (bedtime, trips, poop).
 3. Sound and language are set in the same menu.


9. COMMON PROBLEMS
------------------------------------------------------------------------------
 Compile error "xyz.h: No such file"    one of the three libraries is missing
                                        (section 3) or a project file is not
                                        in the folder "TamaPoke".
 Partition Scheme not in the list       update the ESP32 package (section 2)
                                        and select the board
                                        "ESP32S3 Dev Module".
 Black display / restart loop           set PSRAM to "OPI PSRAM" (section 4).
 Port missing or upload aborts          download mode (section 5), a different
                                        USB cable, close the Serial Monitor.
 "No sprites"                           check the SD card (section 6).

==============================================================================
TamaPoke v5.91
